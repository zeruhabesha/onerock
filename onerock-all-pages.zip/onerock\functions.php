<?php
/**
 * OneRock Theme Functions
 * 
 * @package OneRock
 * @version 1.0.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue styles and scripts
 */
function onerock_enqueue_assets() {
    // Main stylesheet
    wp_enqueue_style('onerock-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Google Fonts
    wp_enqueue_style(
        'google-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap',
        array(),
        null
    );
    
    // JavaScript - animations
    if (file_exists(get_template_directory() . '/animations.js')) {
        wp_enqueue_script(
            'onerock-animations',
            get_template_directory_uri() . '/animations.js',
            array(),
            '1.0.0',
            true
        );
    }
    
    // Add theme toggle functionality
    wp_add_inline_script('onerock-animations', "
        document.addEventListener('DOMContentLoaded', function() {
            const themeToggle = document.getElementById('themeToggle');
            const body = document.body;
            
            // Check for saved theme preference
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                body.classList.add('dark-mode');
            }
            
            // Toggle theme
            if (themeToggle) {
                themeToggle.addEventListener('click', function() {
                    body.classList.toggle('dark-mode');
                    const isDark = body.classList.contains('dark-mode');
                    localStorage.setItem('theme', isDark ? 'dark' : 'light');
                });
            }
        });
    ");
}
add_action('wp_enqueue_scripts', 'onerock_enqueue_assets');

/**
 * Theme setup
 */
function onerock_theme_support() {
    // Add default posts and comments RSS feed links to head
    add_theme_support('automatic-feed-links');
    
    // Let WordPress manage the document title
    add_theme_support('title-tag');
    
    // Enable support for Post Thumbnails
    add_theme_support('post-thumbnails');
    
    // Add support for custom logo
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // Add HTML5 support
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'onerock'),
        'footer'  => __('Footer Menu', 'onerock'),
    ));
    
    // Add support for responsive embeds
    add_theme_support('responsive-embeds');
    
    // Add support for editor styles
    add_theme_support('editor-styles');
    
    // Add support for wide alignment
    add_theme_support('align-wide');
}
add_action('after_setup_theme', 'onerock_theme_support');

/**
 * Register widget areas
 */
function onerock_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget Area', 'onerock'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets here to appear in your footer.', 'onerock'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'onerock_widgets_init');

/**
 * Customizer settings
 */
function onerock_customize_register($wp_customize) {
    // Hero Section
    $wp_customize->add_section('hero_section', array(
        'title'    => __('Hero Section', 'onerock'),
        'priority' => 30,
    ));
    
    // Hero Label
    $wp_customize->add_setting('hero_label', array(
        'default'           => 'Shopify Experts',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_label', array(
        'label'   => __('Hero Label', 'onerock'),
        'section' => 'hero_section',
        'type'    => 'text',
    ));
    
    // Hero Headline
    $wp_customize->add_setting('hero_headline', array(
        'default'           => 'Build Your Shopify Empire',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_headline', array(
        'label'   => __('Hero Headline', 'onerock'),
        'section' => 'hero_section',
        'type'    => 'text',
    ));
    
    // Hero Description
    $wp_customize->add_setting('hero_description', array(
        'default'           => 'Expert Shopify development and consulting services',
        'sanitize_callback' => 'sanitize_textarea_field',
    ));
    
    $wp_customize->add_control('hero_description', array(
        'label'   => __('Hero Description', 'onerock'),
        'section' => 'hero_section',
        'type'    => 'textarea',
    ));
    
    // Hero Button Text
    $wp_customize->add_setting('hero_btn_text', array(
        'default'           => 'Get Started',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_btn_text', array(
        'label'   => __('Hero Button Text', 'onerock'),
        'section' => 'hero_section',
        'type'    => 'text',
    ));
    
    // Hero Button Link
    $wp_customize->add_setting('hero_btn_link', array(
        'default'           => '#contact',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('hero_btn_link', array(
        'label'   => __('Hero Button Link', 'onerock'),
        'section' => 'hero_section',
        'type'    => 'url',
    ));
}
add_action('customize_register', 'onerock_customize_register');

/**
 * Add body classes
 */
function onerock_body_classes($classes) {
    // Add class for homepage
    if (is_front_page()) {
        $classes[] = 'home-page';
    }
    
    return $classes;
}
add_filter('body_class', 'onerock_body_classes');
