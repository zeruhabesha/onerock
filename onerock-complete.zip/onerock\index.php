<?php
/**
 * The main template file
 * 
 * @package OneRock
 */

get_header();
?>

<!-- Blog Header -->
<div class="wp-block-uagb-container uagb-block-blog-header-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-blog-header-mid">
                <div class="wp-block-uagb-container uagb-block-blog-header-deep">
                    <header class="page-header">
                        <div class="header-container">
                            <h1 class="header-title reveal-text shimmer-text">
                                <?php 
                                if (is_home() && !is_front_page()) {
                                    single_post_title();
                                } elseif (is_archive()) {
                                    the_archive_title();
                                } elseif (is_search()) {
                                    printf(__('Search Results for: %s', 'onerock'), '<span>' . get_search_query() . '</span>');
                                } else {
                                    _e('Insights for Shopify Success', 'onerock');
                                }
                                ?>
                            </h1>
                            <p class="header-subtitle animate slide-up delay-100">
                                <?php 
                                if (is_archive()) {
                                    the_archive_description();
                                } else {
                                    _e('Practical advice, growth strategies, and the latest Shopify updates.', 'onerock');
                                }
                                ?>
                            </p>
                        </div>
                    </header>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Blog Feed -->
<div class="wp-block-uagb-container uagb-block-blog-feed-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-blog-feed-mid">
                <div class="wp-block-uagb-container uagb-block-blog-feed-deep">
                    <section class="blog-feed">
                        <div class="container">
                            <?php if (have_posts()) : ?>
                                <div class="blog-grid-full stagger-container">
                                    <?php while (have_posts()) : the_post(); ?>
                                        <article id="post-<?php the_ID(); ?>" <?php post_class('blog-card-detailed glass-card animate slide-up'); ?>>
                                            <?php if (has_post_thumbnail()) : ?>
                                                <div class="blog-image">
                                                    <a href="<?php the_permalink(); ?>">
                                                        <?php the_post_thumbnail('large'); ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="blog-content">
                                                <span class="blog-category"><?php the_category(', '); ?></span>
                                                <h2 class="blog-title">
                                                    <a href="<?php the_permalink(); ?>" style="text-decoration: none; color: inherit;">
                                                        <?php the_title(); ?>
                                                    </a>
                                                </h2>
                                                <div class="blog-excerpt">
                                                    <?php the_excerpt(); ?>
                                                </div>
                                                <a href="<?php the_permalink(); ?>" class="read-more"><?php _e('Read Full Article →', 'onerock'); ?></a>
                                                <span class="blog-date" style="display: block; margin-top: 10px; font-size: 0.9em; color: var(--text-muted);">
                                                    <?php echo get_the_date(); ?>
                                                </span>
                                            </div>
                                        </article>
                                    <?php endwhile; ?>
                                </div>
                                
                                <!-- Pagination -->
                                <div class="blog-footer">
                                    <?php
                                    the_posts_pagination(array(
                                        'mid_size'  => 2,
                                        'prev_text' => __('&larr; Previous', 'onerock'),
                                        'next_text' => __('Next &rarr;', 'onerock'),
                                    ));
                                    ?>
                                </div>
                                
                            <?php else : ?>
                                <div class="no-posts-found">
                                    <p><?php _e('No posts found.', 'onerock'); ?></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Newsletter Section -->
<div class="wp-block-uagb-container uagb-block-newsletter-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-newsletter-mid">
                <div class="wp-block-uagb-container uagb-block-newsletter-deep">
                    <section class="newsletter-section bg-dark text-white">
                        <div class="container text-center">
                            <h2><?php _e('Get Shopify Tips in Your Inbox', 'onerock'); ?></h2>
                            <p><?php _e('Join 2,000+ brand owners who receive our weekly Shopify growth newsletter.', 'onerock'); ?></p>
                            <form class="newsletter-form">
                                <input type="email" placeholder="<?php esc_attr_e('Enter your email', 'onerock'); ?>" required>
                                <button type="submit" class="btn btn-primary"><?php _e('Subscribe', 'onerock'); ?></button>
                            </form>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Partners Marquee -->
<section class="partners-section" style="padding: 60px 0; background: var(--bg-secondary);">
    <div class="partners-container">
        <h4 class="partners-title" style="text-align: center; margin-bottom: 40px;"><?php _e('Trusted by Industry Leaders', 'onerock'); ?></h4>
        <div class="partners-marquee-container">
            <div class="partners-marquee">
                <!-- Static Partners for now (could be dynamic later) -->
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify"></div>
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify Plus"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/klaviyo-1.svg" alt="Klaviyo"></div>
                <div class="partner-logo"><img src="https://static.yotpo.com/wp-content/themes/yotpo/assets/images/yotpo-logo.svg" alt="Yotpo"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/judgeme.svg" alt="Judge.me"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/tidio.svg" alt="Tidio"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/recharge.svg" alt="Recharge"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/nosto-1.svg" alt="Nosto"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/rebuy.svg" alt="Rebuy"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/shopify-logo.svg" alt="SEOAnt"></div>
                <!-- Duplicated for seamless loop -->
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify"></div>
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify Plus"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/klaviyo-1.svg" alt="Klaviyo"></div>
                <div class="partner-logo"><img src="https://static.yotpo.com/wp-content/themes/yotpo/assets/images/yotpo-logo.svg" alt="Yotpo"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/judgeme.svg" alt="Judge.me"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/tidio.svg" alt="Tidio"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/recharge.svg" alt="Recharge"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/nosto-1.svg" alt="Nosto"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/rebuy.svg" alt="Rebuy"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/shopify-logo.svg" alt="SEOAnt"></div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
