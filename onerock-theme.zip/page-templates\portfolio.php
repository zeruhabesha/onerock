<?php
/**
 * Template Name: Portfolio / Our Work
 * 
 * @package OneRock
 */

get_header();
?>

<!-- Page Header -->
<section class="page-hero portfolio-hero">
    <div class="page-hero-container">
        <div class="page-hero-content animate fade-in">
            <h6 class="page-label">Our Work</h6>
            <h1 class="page-title reveal-text">Shopify Stores Built for Growth</h1>
            <p class="page-subtitle">
                We've helped dozens of brands launch, optimize, and scale their Shopify stores. 
                From startups to established businesses, see how we turn vision into results.
            </p>
        </div>
    </div>
</section>

<!-- Portfolio Grid -->
<section class="portfolio-showcase-section">
    <div class="portfolio-showcase-container">
        
        <!-- Filter Tabs (Optional) -->
        <div class="portfolio-filters animate slide-up">
            <button class="filter-btn active" data-filter="all">All Projects</button>
            <button class="filter-btn" data-filter="ecommerce">Ecommerce</button>
            <button class="filter-btn" data-filter="redesign">Redesigns</button>
            <button class="filter-btn" data-filter="migration">Migrations</button>
        </div>

        <!-- Portfolio Grid -->
        <div class="portfolio-grid stagger-container">
            
            <!-- Project 1 -->
            <article class="portfolio-card animate slide-up" data-category="ecommerce">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-1.jpg" alt="Project 1" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Shopify Plus</span>
                        <span class="tag">Redesign</span>
                    </div>
                    <h3 class="portfolio-card-title">Premium Fashion Brand</h3>
                    <p class="portfolio-card-description">
                        Complete store redesign with custom theme development, resulting in 150% increase in conversions.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">+150%</span>
                            <span class="stat-label">Conversion Rate</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">$2M+</span>
                            <span class="stat-label">Annual Revenue</span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Project 2 -->
            <article class="portfolio-card animate slide-up" data-category="migration">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-2.jpg" alt="Project 2" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Migration</span>
                        <span class="tag">WooCommerce</span>
                    </div>
                    <h3 class="portfolio-card-title">Health & Wellness Store</h3>
                    <p class="portfolio-card-description">
                        Seamless migration from WooCommerce to Shopify Plus with zero downtime and improved performance.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">50%</span>
                            <span class="stat-label">Faster Load Time</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">Zero</span>
                            <span class="stat-label">Downtime</span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Project 3 -->
            <article class="portfolio-card animate slide-up" data-category="ecommerce">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-3.jpg" alt="Project 3" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Shopify</span>
                        <span class="tag">Launch</span>
                    </div>
                    <h3 class="portfolio-card-title">Artisan Coffee Brand</h3>
                    <p class="portfolio-card-description">
                        Brand new Shopify store launch with subscription integration and custom product builder.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">$500K</span>
                            <span class="stat-label">First Year Revenue</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">30%</span>
                            <span class="stat-label">Subscription Rate</span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Project 4 -->
            <article class="portfolio-card animate slide-up" data-category="redesign">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-4.jpg" alt="Project 4" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Shopify Plus</span>
                        <span class="tag">CRO</span>
                    </div>
                    <h3 class="portfolio-card-title">Tech Accessories Brand</h3>
                    <p class="portfolio-card-description">
                        Conversion rate optimization through UX redesign and checkout flow improvements.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">+85%</span>
                            <span class="stat-label">Cart Completion</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">+120%</span>
                            <span class="stat-label">Mobile Sales</span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Project 5 -->
            <article class="portfolio-card animate slide-up" data-category="ecommerce">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-5.jpg" alt="Project 5" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Shopify</span>
                        <span class="tag">B2B</span>
                    </div>
                    <h3 class="portfolio-card-title">Wholesale Beauty Supplier</h3>
                    <p class="portfolio-card-description">
                        B2B Shopify store with custom pricing, bulk ordering, and wholesale portal integration.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">200+</span>
                            <span class="stat-label">B2B Clients</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">$1.5M</span>
                            <span class="stat-label">Wholesale Revenue</span>
                        </div>
                    </div>
                </div>
            </article>

            <!-- Project 6 -->
            <article class="portfolio-card animate slide-up" data-category="redesign">
                <div class="portfolio-card-image">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/portfolio-6.jpg" alt="Project 6" loading="lazy">
                    <div class="portfolio-card-overlay">
                        <a href="#" class="portfolio-view-btn">View Case Study →</a>
                    </div>
                </div>
                <div class="portfolio-card-content">
                    <div class="portfolio-card-tags">
                        <span class="tag">Shopify Plus</span>
                        <span class="tag">International</span>
                    </div>
                    <h3 class="portfolio-card-title">Global Apparel Brand</h3>
                    <p class="portfolio-card-description">
                        Multi-currency, multi-language store expansion to 15 countries with localized experiences.
                    </p>
                    <div class="portfolio-card-stats">
                        <div class="stat">
                            <span class="stat-value">15</span>
                            <span class="stat-label">Countries</span>
                        </div>
                        <div class="stat">
                            <span class="stat-value">+300%</span>
                            <span class="stat-label">International Sales</span>
                        </div>
                    </div>
                </div>
            </article>

        </div>
    </div>
</section>

<!-- CTA Section -->
<section class="portfolio-cta-section">
    <div class="portfolio-cta-container">
        <div class="portfolio-cta-content animate fade-in">
            <h2 class="portfolio-cta-title">Ready to Start Your Project?</h2>
            <p class="portfolio-cta-text">
                Let's build something amazing together. Book a free consultation to discuss your Shopify goals.
            </p>
            <div class="portfolio-cta-buttons">
                <a href="<?php echo esc_url(home_url('/contact')); ?>" class="btn btn-primary">Get Started</a>
                <a href="#" class="btn btn-secondary">View Services</a>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
