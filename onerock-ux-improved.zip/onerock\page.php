<?php
/**
 * The template for displaying all pages
 * 
 * @package OneRock
 */

get_header();
?>

<!-- Generic Page Header -->
<div class="wp-block-uagb-container uagb-block-page-header-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-page-header-mid">
                <div class="wp-block-uagb-container uagb-block-page-header-deep">
                    <header class="page-header">
                        <div class="header-container">
                            <h1 class="header-title reveal-text shimmer-text"><?php the_title(); ?></h1>
                        </div>
                    </header>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Page Content -->
<div class="container" style="padding: 60px 20px;">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</div>

<?php get_footer(); ?>
