document.addEventListener('DOMContentLoaded', () => {
    // 1. Text Reveal Setup (Splitting headers into words)
    const revealElements = document.querySelectorAll('.reveal-text');
    revealElements.forEach(el => {
        const text = el.textContent.trim();
        const words = text.split(' ');
        el.innerHTML = words.map(word => `<span class="word-wrap"><span class="word">${word}</span></span>`).join(' ');
    });

    // 2. Intersection Observer for Scroll Animations
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // observer.unobserve(entry.target); // Keep observing if we want re-animation, but typically once is cleaner
            }
        });
    }, observerOptions);

    const animatedElements = document.querySelectorAll('.animate, .reveal-text');
    animatedElements.forEach(el => observer.observe(el));

    // 3. Staggered Entrance Indexer
    const staggerContainers = document.querySelectorAll('.stagger-container');
    staggerContainers.forEach(container => {
        const items = container.querySelectorAll('.animate');
        items.forEach((item, index) => {
            item.style.setProperty('--stagger-index', index);
        });
    });

    // 4. Interactive Magnetic Glow Effect
    const glow = document.createElement('div');
    glow.className = 'interactive-glow';
    document.body.appendChild(glow);

    // Magnetic CTA Logic
    const magneticBtns = document.querySelectorAll('.magnetic-wrap');

    window.addEventListener('mousemove', (e) => {
        // Interactive Glow
        requestAnimationFrame(() => {
            glow.style.left = `${e.clientX}px`;
            glow.style.top = `${e.clientY}px`;
        });

        // Magnetic Effect with Lerner Easing
        magneticBtns.forEach(btn => {
            const rect = btn.getBoundingClientRect();
            const btnX = rect.left + rect.width / 2;
            const btnY = rect.top + rect.height / 2;

            const x = e.clientX - btnX;
            const y = e.clientY - btnY;
            const distance = Math.sqrt(x * x + y * y);

            if (distance < 120) {
                // Closer influence area, smoother movement
                const strength = 0.35;
                btn.style.transform = `translate(${x * strength}px, ${y * strength}px)`;
                btn.classList.add('is-active');
            } else {
                btn.style.transform = `translate(0px, 0px)`;
                btn.classList.remove('is-active');
            }
        });
    });

    // 5. Navbar & Parallax Logic
    const navbar = document.querySelector('.main-nav');

    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;

        // Navbar state
        if (scrolled > 50) {
            navbar?.classList.add('scrolled');
        } else {
            navbar?.classList.remove('scrolled');
        }

        // Parallax Effects with Smooth Easing
        const parallaxElements = document.querySelectorAll('.hero-visual, .sub-service, .project-card, .blog-card, .process-step, .faq-item');
        parallaxElements.forEach(el => {
            const rect = el.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            // Check if element is in viewport
            if (rect.top < viewportHeight && rect.bottom > 0) {
                const speed = el.classList.contains('hero-visual') ? 0.05 : 0.03;
                const center = rect.top + rect.height / 2;
                const diff = center - (viewportHeight / 2);
                el.style.transform = `translateY(${diff * speed}px)`;
            }
        });
    });
});
