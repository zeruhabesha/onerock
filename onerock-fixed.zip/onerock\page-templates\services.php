<?php
/**
 * Template Name: Services Page
 * 
 * @package OneRock
 */

get_header();
?>

<!-- Page Header -->
<div class="wp-block-uagb-container uagb-block-page-header-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-page-header-mid">
                <div class="wp-block-uagb-container uagb-block-page-header-deep">
                    <header class="page-header">
                        <div class="header-container">
                            <h1 class="header-title reveal-text shimmer-text"><?php the_title(); ?></h1>
                            <p class="header-subtitle animate slide-up delay-100">
                                <?php echo get_post_meta(get_the_ID(), 'subtitle', true) ?: 'Comprehensive solutions for every stage of your ecommerce journey.'; ?>
                            </p>
                        </div>
                    </header>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Services Overview -->
<div class="wp-block-uagb-container uagb-block-services-overview-root alignfull uagb-is-root-container">
    <div class="uagb-container-inner-blocks-wrap">
        <div class="wp-block-group">
            <div class="wp-block-uagb-container uagb-block-services-overview-mid">
                <div class="wp-block-uagb-container uagb-block-services-overview-deep">
                    <section class="services-overview-page">
                        <div class="container">
                            <!-- Phase 1: PLAN -->
                            <div class="service-phase">
                                <div class="phase-header">
                                    <span class="phase-number">01</span>
                                    <h2 class="phase-title reveal-text">PLAN: Strategy & Consulting</h2>
                                </div>
                                <div class="phase-grid stagger-container">
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Digital Business Analysis</h3>
                                        <p>We dive deep into your funnels, pricing, and performance to identify hidden growth opportunities.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Growth Objectives & KPIs</h3>
                                        <p>Setting clear, measurable goals that align with your brand vision and business priorities.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Tailored Growth Strategies</h3>
                                        <p>Data-driven roadmaps designed to help you scale sustainably and predictably on Shopify.</p>
                                    </div>
                                </div>
                            </div>

                            <hr class="phase-divider">

                            <!-- Phase 2: BUILD -->
                            <div class="service-phase">
                                <div class="phase-header">
                                    <span class="phase-number">02</span>
                                    <h2 class="phase-title reveal-text">BUILD: Design & Development</h2>
                                </div>
                                <div class="phase-grid stagger-container">
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Shopify & Plus Development</h3>
                                        <p>Custom theme builds, Liquid expert adjustments, and advanced functionality tailored for results.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>UI/UX Design</h3>
                                        <p>Conversion-first design that builds trust and guides users seamlessly toward checkout.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>App Integration & Automation</h3>
                                        <p>Streamline your ops with custom integrations that eliminate busywork and improve efficiency.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Store Setup & Launch</h3>
                                        <p>Launching your brand with confidence, from theme configuration to shipping and tax setup.</p>
                                    </div>
                                </div>
                            </div>

                            <hr class="phase-divider">

                            <!-- Phase 3: GROW -->
                            <div class="service-phase">
                                <div class="phase-header">
                                    <span class="phase-number">03</span>
                                    <h2 class="phase-title reveal-text">GROW: Marketing & Support</h2>
                                </div>
                                <div class="phase-grid stagger-container">
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>SEO & AI Search Visibility</h3>
                                        <p>Future-ready search optimization for traditional search engines and AI-driven discovery.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>CRO (Conversion Rate Optimization)</h3>
                                        <p>Continuous A/B testing and design refinements to maximize every visitor's value.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>Email & Retention</h3>
                                        <p>Personalized email flows and loyalty strategies that turn one-time buyers into fans.</p>
                                    </div>
                                    <div class="service-card-detailed glass-card animate slide-up">
                                        <h3>VA & Store Management</h3>
                                        <p>Daily operational support to keep your store running smoothly while you focus on vision.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Partners Marquee -->
<section class="partners-section" style="padding: 60px 0; background: var(--bg-secondary);">
    <div class="partners-container">
        <h4 class="partners-title" style="text-align: center; margin-bottom: 40px;">Trusted by Industry Leaders</h4>
        <div class="partners-marquee-container">
            <div class="partners-marquee">
                <!-- Static Partners for now -->
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify"></div>
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify Plus"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/klaviyo-1.svg" alt="Klaviyo"></div>
                <div class="partner-logo"><img src="https://static.yotpo.com/wp-content/themes/yotpo/assets/images/yotpo-logo.svg" alt="Yotpo"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/judgeme.svg" alt="Judge.me"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/tidio.svg" alt="Tidio"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/recharge.svg" alt="Recharge"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/nosto-1.svg" alt="Nosto"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/rebuy.svg" alt="Rebuy"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/shopify-logo.svg" alt="SEOAnt"></div>
                <!-- Duplicated for seamless loop -->
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify"></div>
                <div class="partner-logo"><img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify Plus"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/klaviyo-1.svg" alt="Klaviyo"></div>
                <div class="partner-logo"><img src="https://static.yotpo.com/wp-content/themes/yotpo/assets/images/yotpo-logo.svg" alt="Yotpo"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/judgeme.svg" alt="Judge.me"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/tidio.svg" alt="Tidio"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/recharge.svg" alt="Recharge"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/nosto-1.svg" alt="Nosto"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/rebuy.svg" alt="Rebuy"></div>
                <div class="partner-logo"><img src="https://cdn.worldvectorlogo.com/logos/shopify-logo.svg" alt="SEOAnt"></div>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
